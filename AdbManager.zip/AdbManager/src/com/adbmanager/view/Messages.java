package com.adbmanager.view;

public class Messages {
	
	public static final String ADB_DEVICES_LIST = "List of devices attached";
	
	public static final String CONNECTED = "device";
	public static final String CONNECTING = "connecting";
	public static final String UNAUTHORIZED = "unauthorized";
	public static final String OFFLINE = "offline";
	
	public static final String VERSION = "0.0.1";

}
